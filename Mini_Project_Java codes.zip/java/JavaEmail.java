import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class JavaEmail {
    public static void sendMail(String recepient,String email1,String phnnumber,String name) throws MessagingException {
        System.out.println("Preparing Email...");
        Properties properties = new Properties();

        // Fixing incorrect property keys
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        // Sender email credentials
        String email = "agameeevent25@gmail.com";
        String password = "ptis iase xwgg tpbz";

        // Authenticator to login
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(email, password);
            }
        });

        Message message = prepareMessage(session, email, recepient,email1,phnnumber,name);
        try {
            Transport.send(message);
            System.out.println("Email sent successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Message prepareMessage(Session session, String email, String recepient,String email1,String phnnumber,String name ) throws MessagingException {
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(email));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
        message.setSubject("Thank You from Agamee Events!");
        message.setText("Dear"+name+"\n" +
"\n" +
"Vanakkam!\n" +
"Thank you so much for choosing Agamee Events. It was truly a pleasure to work with you on your recent event.\n" +
"\n" +
"We deeply appreciate your trust in our team, and we hope our services helped make your occasion special and memorable. Your support means a lot to us!\n" +
"\n" +
"If you have any feedback or future event plans, we would be more than happy to assist again.\n" +
"\n" +
"Warm regards,\n" +
"AGAMEE EVENT\nPhone Number : " +
phnnumber +
"EMAIL :"+email1+"\n "
        + " Thank you visit Again ...... ");

        return message;
    }
}