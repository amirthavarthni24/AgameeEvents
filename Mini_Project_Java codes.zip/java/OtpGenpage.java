import java.io.IOException;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.mail.MessagingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/OtpGenpage")
public class OtpGenpage extends HttpServlet {

    private String generateOTP() {
        SecureRandom random = new SecureRandom();
        int otp = 100000 + random.nextInt(900000); // 6-digit OTP
        return String.valueOf(otp);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        String email = request.getParameter("emailuser");
        String otp = generateOTP();

        try (PrintWriter out = response.getWriter()) {
            Class.forName("oracle.jdbc.driver.OracleDriver");

            try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
                 PreparedStatement pst = con.prepareStatement("SELECT COUNT(*) FROM info_storetable WHERE EMAIL_USER = ?")) {

                pst.setString(1, email);
                ResultSet rs = pst.executeQuery();

                if (rs.next() && rs.getInt(1) > 0) {
                    // Email found - send OTP
                    OTP_Genrate.sendMail(email, otp); // Make sure this class/method exists
                    session.setAttribute("otp", otp);
                    session.setAttribute("email", email);

                    RequestDispatcher disp = request.getRequestDispatcher("password_change.jsp");
                    disp.forward(request, response);

                } else {
                    request.setAttribute("message", "Email not registered in our system.");
                    RequestDispatcher disp = request.getRequestDispatcher("otp_error.jsp");
                    disp.forward(request, response);
                }

            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("message", "Database error: " + e.getMessage());
                request.getRequestDispatcher("otp_error.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Internal error: " + e.getMessage());
            request.getRequestDispatcher("otp_error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Generates OTP and sends email for verification";
    }
}
