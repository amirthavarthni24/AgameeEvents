import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class javasendpersonal {
    public static void sendMail(String recepient,String name,String place,String service) throws MessagingException {
        System.out.println("Preparing Email...");
        Properties properties = new Properties();

        // Fixing incorrect property keys
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        // Sender email credentials
        String email = "agameeevent25@gmail.com";
        String password = "ptis iase xwgg tpbz";

        // Authenticator to login
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(email, password);
            }
        });

        Message message = prepareMessage(session, email, recepient,name,place,service);
        try {
            Transport.send(message);
            System.out.println("Email sent successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Message prepareMessage(Session session, String email, String recepient,String name,String place,String service) throws MessagingException {
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(email));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
        message.setSubject(" Event Booking Confirmation – Agamee Events");
        message.setText(service+"Dear"+name+"\n" +
                "\n" +
                "Vanakkam!\n" +
                "\n" +
                "Thank you for choosing Agamee Events. We are pleased to confirm your booking for the upcoming event.\n" +
                "\n" +
                "Booking Details:\n • Event Name/Type:"+service+ "\n Venue:" +place +"\n Other details TO visit our website \n" +
"\n" +
"Our team is excited to make your event special and memorable. If there are any additional requirements or changes, please feel free to contact us at [Phone Number] or reply to this email.\n" +
"\n" +
"Looking forward to a successful event!\n" +
"\n" +
"Warm regards,\n" +
"Agamee Events\n" +
"7812833846\n" +
recepient);

        return message;
    }
}