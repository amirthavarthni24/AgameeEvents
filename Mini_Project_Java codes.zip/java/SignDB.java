import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SignDB extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("user_name");
        String email = request.getParameter("email_username");
        String pword = request.getParameter("pword_userword");
        String rpword = request.getParameter("rpword_userword");

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");

            // Step 1: Check if Email already exists
            String checkQuery = "SELECT email_user FROM info_storetable WHERE email_user = ?";
            pst = con.prepareStatement(checkQuery);
            pst.setString(1, email); // index 1, not 2
            rs = pst.executeQuery();

            if (rs.next()) {
                // Email already exists
                String strerror = "Email already registered!";
                request.setAttribute("error", strerror);
                RequestDispatcher disp = request.getRequestDispatcher("loginpage.jsp");
                disp.forward(request, response);
                return; // Stop further execution
            }

            // Step 2: Insert the new user if email not exists
            rs.close(); // close previous ResultSet
            pst.close(); // close previous PreparedStatement

            if (!pword.equals(rpword)) {
                // Passwords don't match
                String strerror = "Passwords do not match!";
                request.setAttribute("error", strerror);
                RequestDispatcher disp = request.getRequestDispatcher("loginpage.jsp");
                disp.forward(request, response);
                return;
            }

            String insertQuery = "INSERT INTO info_storetable (username, email_user, email_password, rpassword) VALUES (?, ?, ?, ?)";
            pst = con.prepareStatement(insertQuery);
            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, pword);
            pst.setString(4, rpword);

            int rowsInserted = pst.executeUpdate();
            if (rowsInserted > 0) {
                // Signup successful
                request.setAttribute("success", "Signup Successful! Please login.");
                RequestDispatcher disp = request.getRequestDispatcher("loginpage.jsp");
                disp.forward(request, response);
            } else {
                // Something went wrong
                String strerror = "Signup failed! Try again.";
                request.setAttribute("error", strerror);
                RequestDispatcher disp = request.getRequestDispatcher("loginpage.jsp");
                disp.forward(request, response);
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Internal Server Error. Please try again later.");
            RequestDispatcher disp = request.getRequestDispatcher("loginpage.jsp");
            disp.forward(request, response);
        } finally {
            // Close resources
            try { if (rs != null) rs.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            try { if (pst != null) pst.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            try { if (con != null) con.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Handles User Sign Up functionality";
    }
}