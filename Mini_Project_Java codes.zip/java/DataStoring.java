import java.io.IOException;
import java.io.PrintWriter; // ✅ You missed this import
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/DataStoring")
public class DataStoring extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter(); // ✅ Now it will work

        String name = request.getParameter("name1");
        String mobile = request.getParameter("mobile1");
        String Adate = request.getParameter("date1");
        String email = request.getParameter("email1");
        String place = request.getParameter("place1");
        String service = request.getParameter("services1");
        String message = request.getParameter("message1");
        String msg = request.getParameter("msgidenticator");

        try {
            Date sqlDate = Date.valueOf(Adate);
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:xe", "system", "system"
            );

            PreparedStatement pst = null;
            HttpSession session1=request.getSession(true);
            switch (service) {
                case "Birthday Party":
                    out.println("Birthday Party Insert");
                    
                    String totalamt=(String)session1.getAttribute("totalamtpaying");
                    String advancetotalamt=(String)session1.getAttribute("advancepayingamt");
                    String transectionid=(String)session1.getAttribute("transectionid");
                    out.println(totalamt);
                    out.println(advancetotalamt);
                    out.println(transectionid);
                    String imagename1 = request.getParameter("imagename1");
                    String imagename2 = request.getParameter("imagename2");
                    String imagename3 = request.getParameter("imagename3");
                    String imagename4 = request.getParameter("imagename4");
                    String imagename5 = request.getParameter("imagename5");
                    String imagename6 = request.getParameter("imagename6");
                    String imagename7 = request.getParameter("imagename7");
                    String imagename8 = request.getParameter("imagename8");
                    String imagename9 = request.getParameter("imagename9");
                    String imagename10 = request.getParameter("imagename10");
                    String imagename11 = request.getParameter("imagename11");

                    String bQuery = "INSERT INTO DataStoring_Birthday " +
                        "(Name, MobileNumber, Adatte, Email, place, message, AssignedTeam, " +
                        "ImageName1, ImageName2, ImageName3, ImageName4, ImageMName5, ImageName6, " +
                        "ImageName7, ImageName8, ImageName9, ImageName10, ImageName11, assignteamname,TOTALAMTPAYED,ADVANCEAMTPAYED,TRANSECTIONID) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

                    pst = con.prepareStatement(bQuery);
                    pst.setString(1, name);
                    pst.setString(2, mobile);
                    pst.setDate(3, sqlDate);
                    pst.setString(4, email);
                    pst.setString(5, place);
                    pst.setString(6, message);
                    pst.setString(7, service);
                    pst.setString(8, imagename1);
                    pst.setString(9, imagename2);
                    pst.setString(10, imagename3);
                    pst.setString(11, imagename4);
                    pst.setString(12, imagename5);
                    pst.setString(13, imagename6);
                    pst.setString(14, imagename7);
                    pst.setString(15, imagename8);
                    pst.setString(16, imagename9);
                    pst.setString(17, imagename10);
                    pst.setString(18, imagename11);
                    pst.setString(19, msg);
                    pst.setString(20,totalamt);
                    pst.setString(21,advancetotalamt);
                    pst.setString(22,transectionid);
                    break;

                case "Marriage":
                    out.println("Marriage Insert");
                    
                   String totalamt1=(String)session1.getAttribute("totalamtpaying");
                    String advancetotalamt1=(String)session1.getAttribute("advancepayingamt");
                    String transectionid1=(String)session1.getAttribute("transectionid");
                    
                    String imagename22 = request.getParameter("imagename22");
                    String imagename23 = request.getParameter("imagename23");
                    String imagename24 = request.getParameter("imagename24");
                    String imagename25 = request.getParameter("imagename25");
                    String imagename26 = request.getParameter("imagename26");
                    String imagename27 = request.getParameter("imagename27");
                    String imagename28 = request.getParameter("imagename28");
                    String imagename29 = request.getParameter("imagename29");
                    String imagename30 = request.getParameter("imagename30");
                    String imagename31 = request.getParameter("imagename31");
                    String imagename32 = request.getParameter("imagename32");
                    String imagename33 = request.getParameter("imagename33");
                    String imagename34 = request.getParameter("imagename34");
                    String imagename35 = request.getParameter("imagename35");
                    String imagename36 = request.getParameter("imagename36");
                    String imagename37 = request.getParameter("imagename37");

                  String mQuery = "INSERT INTO DataStoring_wedding " +
    "(Name, MobileNumber, Adatte, Email, place, message, AssignedTeam, " +
    "ImageName1, ImageName2, ImageName3, ImageName4, ImageMName5, ImageName6, " +
    "ImageName7, ImageName8, ImageName9, ImageName10, ImageName11, ImageName12, " +
    "ImageName13, ImageName14, ImageName15, ImageName16, AssignedTeamName,TOTALAMTPAYED,ADVANCEAMTPAYED,TRANSECTIONID) " +  // <- Corrected here
    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)";


                    pst = con.prepareStatement(mQuery);
                    pst.setString(1, name);
                    pst.setString(2, mobile);
                    pst.setDate(3, sqlDate);
                    pst.setString(4, email);
                    pst.setString(5, place);
                    pst.setString(6, message);
                    pst.setString(7, service);
                    pst.setString(8, imagename22);
                    pst.setString(9, imagename23);
                    pst.setString(10, imagename24);
                    pst.setString(11, imagename25);
                    pst.setString(12, imagename26);
                    pst.setString(13, imagename27);
                    pst.setString(14, imagename28);
                    pst.setString(15, imagename29);
                    pst.setString(16, imagename30);
                    pst.setString(17, imagename31);
                    pst.setString(18, imagename32);
                    pst.setString(19, imagename33);
                    pst.setString(20, imagename34);
                    pst.setString(21, imagename35);
                    pst.setString(22, imagename36);
                    pst.setString(23,imagename37);
                    pst.setString(24, msg);
                    pst.setString(25,totalamt1);
                    pst.setString(26,advancetotalamt1);
                    pst.setString(27,transectionid1);
                    break;

                case "Puberty":
                    out.println("Puberty Insert");
                    String totalamt2=(String)session1.getAttribute("totalamtpaying");
                    String advancetotalamt2=(String)session1.getAttribute("advancepayingamt");
                    String transectionid2=(String)session1.getAttribute("transectionid");
                    String imagename12 = request.getParameter("imagename12");
                    String imagename13 = request.getParameter("imagename13");
                    String imagename14 = request.getParameter("imagename14");
                    String imagename15 = request.getParameter("imagename15");
                    String imagename16 = request.getParameter("imagename16");
                    String imagename17 = request.getParameter("imagename17");
                    String imagename18 = request.getParameter("imagename18");
                    String imagename19 = request.getParameter("imagename19");
                    String imagename20 = request.getParameter("imagename20");
                    String imagename21 = request.getParameter("imagename21");

                    String pQuery = "INSERT INTO DataStoring_Puberty " +
                        "(Name, MobileNumber, Adatte, Email, place, message, AssignedTeam, " +
                        "ImageName1, ImageName2, ImageName3, ImageName4, ImageMName5, ImageName6, " +
                        "ImageName7, ImageName8, ImageName9, ImageName10, ASSIGNEDTEAMNAME,TOTALAMTPAYED,ADVANCEAMTPAYED,TRANSECTIONID) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

                    pst = con.prepareStatement(pQuery);
                    pst.setString(1, name);
                    pst.setString(2, mobile);
                    pst.setDate(3, sqlDate);
                    pst.setString(4, email);
                    pst.setString(5, place);
                    pst.setString(6, message);
                    pst.setString(7, service);
                    pst.setString(8, imagename12);
                    pst.setString(9, imagename13);
                    pst.setString(10, imagename14);
                    pst.setString(11, imagename15);
                    pst.setString(12, imagename16);
                    pst.setString(13, imagename17);
                    pst.setString(14, imagename18);
                    pst.setString(15, imagename19);
                    pst.setString(16, imagename20);
                    pst.setString(17, imagename21);
                    pst.setString(18, msg);
                    pst.setString(19,totalamt2);
                    pst.setString(20,advancetotalamt2);
                    pst.setString(21,transectionid2);
                    break;

                default:
                    out.println("Invalid Service Type: " + service);
                    return;
            }
            JavaEmail.sendMail(email,"agameeevent25@gmail.com","7812833846",name);
            javasendpersonal.sendMail("agameeevent25@gmail.com",name,place,service);
            pst.executeUpdate();
            con.close();
           
            RequestDispatcher disp=request.getRequestDispatcher("home.jsp");
            disp.forward(request,response);
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Handles event data storage for different teams";
    }
}