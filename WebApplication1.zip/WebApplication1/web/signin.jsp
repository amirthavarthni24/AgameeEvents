<%-- 
    Document   : sign
    Created on : 10 Mar, 2025, 1:54:27 PM
    Author     : Shree
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In / Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: black;
            color: goldenrod;
            margin: 0;
        }
        .container {
            background: black;
            padding: 30px;
            margin-right:70px;
            border-right: 50px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(255, 215, 0, 0.5);
            width: 350px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .logo {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
        }
        .input-group {
            position: relative;
            margin-bottom: 15px;
            width: 110%;
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: goldenrod;
        }
        input {
            width: calc(100% - 20px);
            padding: 10px;
        
            border: 1px solid goldenrod;
            border-radius: 5px;
            background: black;
            color: goldenrod;
            text-align: center;
        }
        .error {
            color: red;
            font-size: 12px;
            text-align: left;
            margin-top: -8px;
            margin-bottom: 8px;
        }
        button {
            background-color: goldenrod;
            color: black;
            padding: 12px;
            border: none;
            width: 100%;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
        }
        .toggle-link {
            color: goldenrod;
            cursor: pointer;
            display: block;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container" id="form-container" >
        <img src="logo1.jpg" alt="Logo" class="logo"style="margin-left:10%;">
        <h2 id="form-title" style="margin-top:2px; margin-left:10%;">Sign In</h2>
        <form id="signin-form" action="Loginvalidate">
            <div class="input-group">
                <input type="email" id="email" placeholder="Email" name="email_user" required>
            </div>
            <div class="input-group">
                <input type="password" id="password" placeholder="Password" name="password_user" required maxlength="8">
                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                <p class="error" id="password-error"></p>
            </div>
            <button type="submit" style="width: 110%;">Sign In</button>
            <span class="toggle-link" onclick="toggleForm()">Don't have an account? Sign Up</span>
        </form>
        <form id="signup-form" style="display: none;" action="SignupDB">
            <div class="input-group">
                <input type="text" id="name" placeholder="Full Name" name="user_name" required>
             </div>
             <div class="input-group">
                <input type="email" id="new-email" placeholder="Email" name="email_username" required>
             </div>
             <div class="input-group">
                <input type="password" id="new-password" placeholder="Password" required maxlength="8" name="pword_userword">
                <span class="toggle-password" onclick="togglePassword('new-password')">👁</span>
                <p class="error" id="new-password-error"></p>
             </div>
             <div class="input-group">
                <input type="password" id="confirm-password" placeholder="Confirm Password" required name="rpword_userword">
                <span class="toggle-password" onclick="togglePassword('confirm-password')">👁</span>
                <p class="error" id="confirm-password-error"></p>
            </div>
            <button type="submit"style="width:110%">Sign Up</button>
            <span class="toggle-link" onclick="toggleForm()">Already have an account? Sign In</span>
        </form>
      </div>
    <script>
        function toggleForm() {
            let signinForm = document.getElementById("signin-form");
            let signupForm = document.getElementById("signup-form");
            let formTitle = document.getElementById("form-title");
            
            if (signinForm.style.display === "none") {
                signinForm.style.display = "block";
                signupForm.style.display = "none";
                formTitle.innerText = "Sign In";
            } else {
                signinForm.style.display = "none";
                signupForm.style.display = "block";
                formTitle.innerText = "Sign Up";
            }
        }
        function togglePassword(id) {
            let passwordField = document.getElementById(id);
            passwordField.type = passwordField.type === "password" ? "text" : "password";
        }

        function validatePassword(password) {
    if (password.length !== 8) {
        return false;
    }

    let hasUpperCase = false;
    let hasLowerCase = false;
    let hasDigit = false;

    for (let i = 0; i < password.length; i++) {
        let char = password[i];

        if (char >= 'A' && char <= 'Z') {
            hasUpperCase = true;
        } else if (char >= 'a' && char <= 'z') {
            hasLowerCase = true;
        } else if (char >= '0' && char <= '9') {
            hasDigit = true;
        }

        // If all conditions are met, no need to continue
        if (hasUpperCase && hasLowerCase && hasDigit) {
            return true;
        }
    }

    return false;
}
       document.getElementById("signup-form").addEventListener("submit", function(event) {
            let password = document.getElementById("new-password").value;
            let confirmPassword = document.getElementById("confirm-password").value;
            if (!validatePassword(password)) {
                alert("Invalid password. Must be exactly 8 characters with at least one uppercase, lowercase, number, and special character.");
                event.preventDefault();
            }
            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                event.preventDefault();
            }
        });
    </script>
</body>
</html>